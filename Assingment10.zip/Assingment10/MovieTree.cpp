#include <iostream>
#include "MovieTree.h"

using namespace std;

MovieTree:: MovieTree(){

    nil = new MovieNode;
    nil->isRed=false;

    root= nil;
    root->parent=nil;
    root->left=nil;
    root->right=nil;

}

MovieTree:: ~MovieTree(){
    DeleteAll(root);
}

//public

void MovieTree::printMovieInventory(){
    MovieNode *node= root;
    printMovieInventory(node);
}

int MovieTree::countMovieNodes(){

    int count = 0;

    countMovieNodes(root, &count);
    return count;
    }
void MovieTree::deleteMovieNode(std::string title){

    MovieNode* remove = searchMovieTree(root, title);

    if(remove == nil){
        cout<<"Movie not found."<<endl;
        return;
    }
    else{
        rbDelete(remove);
    }

}

void MovieTree::addMovieNode(int ranking, std::string title, int year, int quantity){



    if(root == nil){

        root =new  MovieNode(ranking, title, year, quantity);
        root->parent=nil;
        root->isRed=false;
        root->left = nil;
    	root->right = nil;

        //int b = rbValid(root);
        //cout<<b<<endl;
        return;
    }



    MovieNode *temp = root; //root
    MovieNode* parent = nil; //parent


    //node is node to add

    while(temp != nil){//gets to bottom of tree

        parent = temp;//sets temp to parent of location for where node is added

        if(title < temp->title){
            temp=temp->left;
        }
        else{temp=temp->right;}
    }

    MovieNode *node;

    if(title < parent->title){//adds to either left or right
        //cout<<"added to left"<<endl;

        node = new MovieNode(ranking, title, year, quantity);
        node->left = nil;
    	node->right = nil;
        node->parent = nil;

        node->isRed=true;

        parent->left = node;
        node->parent=parent;
    }

    else{
            //cout<<"added to right"<<endl;

        node = new MovieNode(ranking, title, year, quantity);
        node->left = nil;
    	node->right = nil;
        node->parent = nil;

        node->isRed=true;

        parent->right=node;

        node->parent=parent;
    }
    //int a = rbValid(root);

    rbAddFixup(node);//seg fault is here

}

void MovieTree::findMovie(std::string title){
    MovieNode *found = nil;
    found = searchMovieTree(root, title);

    if(found == nil){
        cout<<"Movie not found."<<endl;
    }
    else{
        cout << "Movie Info:" << endl;
        cout << "===========" << endl;
        cout << "Ranking:" << found->ranking << endl;
        cout << "Title:" << found->title << endl;
        cout << "Year:" << found->year << endl;
        cout << "Quantity:" << found->quantity << endl;
    }
}

void MovieTree::rentMovie(std::string title){
    MovieNode *found = nil;
    found = searchMovieTree(root, title);
    if(found == nil){
        cout<<"Movie not found."<<endl;
        return;
    }
    else{
        cout<<"Movie has been rented."<<endl;
        cout << "Movie Info:" << endl;
        cout << "===========" << endl;
        cout << "Ranking:" << found->ranking << endl;
        cout << "Title:" << found->title << endl;
        cout << "Year:" << found->year << endl;
        cout << "Quantity:" << found->quantity - 1 << endl;
        found->quantity=found->quantity-1;
    }
    if(found->quantity == 0){
            deleteMovieNode(found->title);

        }

}
bool MovieTree::isValid(){}
int MovieTree::countLongestPath(){

    int count= countLongestPath(root);

    return count;
}

//private


void MovieTree::DeleteAll(MovieNode * node){
 if(node == nil){
        return;
        }

        DeleteAll(node->left);


        DeleteAll(node->right);


    cout<<"Deleting: "<<node->title<<endl;
}

void MovieTree::printMovieInventory(MovieNode * node){
if(node == nil){
        return;
        }

    printMovieInventory(node->left);

    cout<<"Movie: "<<node->title<<" "<<node->quantity<<endl;

    printMovieInventory(node->right);
}

void MovieTree::rbAddFixup(MovieNode * node ){

    while(node != root && node->parent->isRed==true){

        if(node->parent == node->parent->parent->left){//first event doesn't apply

            MovieNode *uncle = node->parent->parent->right;

            if(uncle ->isRed == true){

                node->parent->isRed=false;//begin rbcase1
                uncle->isRed=false;
                node->parent->parent->isRed=true;//end rbcase1
                node=node->parent->parent;

            }
            else{
                if(node == node->parent->right){
                    node=node->parent;
                    leftRotate(node);
                }
                    node->parent->isRed=false; //case3
                    node->parent->parent->isRed=true;
                    rightRotate(node->parent->parent);//end case3

            }

        }else{

            MovieNode *uncle = node->parent->parent->left;

            if(uncle ->isRed == true){

                node->parent->isRed=false;
                uncle->isRed=false;
                node->parent->parent->isRed=true;
                node=node->parent->parent;

            }
            else{


                if(node == node->parent->left){


                    node=node->parent;
                    rightRotate(node);
                }
                    node->parent->isRed=false;
                    node->parent->parent->isRed=true;

                    leftRotate(node->parent->parent);


            }

    }

}
root->isRed=false;

}

void MovieTree::leftRotate(MovieNode * x){

    MovieNode* y= x->right;
    x->right = y->left;

    if(y->left != nil){

        y->left->parent = x;

    }

    y->parent = x->parent;

    if(x->parent == nil){

        root=y;

    }
    else{
        if(x == x->parent->left){

            x->parent->left = y;
        }
        else{


            x->parent->right=y;
        }
    }
    y->left = x;
    x->parent=y;

}

void MovieTree::rbDelete(MovieNode * node){

    bool nodecolor = node->isRed;
    MovieNode *x = new MovieNode;
    if(node != root && node == node->parent->left){//left side
        //cout<<node->title<<" is the left of its parent."<<endl;
        if(node->left == nil && node->right == nil){//no children
            node->parent->left = nil;
            x = node->parent->left;
        }

        else if(node->left != nil and node->right !=nil){//two children

            MovieNode *min;
            MovieNode *temp= node->right;
            while(temp->left != nil){        //finds minimum of right child of node to delete
                temp = temp->left;
                }
            min = temp;
            nodecolor = min->isRed;

            x = min->right;
             //cout<<"the minimum left of the right this movie is "<<min->title<<endl;

            if(min == node->right){
                node->parent->left = min;
                min->parent = node->parent;
                min->left = node->left;
                min->left->parent = min;
            }
            else{
                min->parent->left = min->right;
                min->right->parent = min->parent;
                min->parent = node->parent;
                node->parent->left=min;
                min->left = node->left;
                min->right = node->right;
                node->right->parent = min;
                node->left->parent = min;
            }
            min->isRed = node->isRed;

        }

        else{ //one child
            x = node->left;
            node->parent->left = x;
            x->parent = node->parent;
        }
    }

    else{ //right side
            //cout<<node->title<<" is the right of its parent."<<endl;
            if(node->left == nil && node->right == nil){//no children
            node->parent->right = nil;
            x = node->parent->right;
        }

        else if(node->left != nil and node->right !=nil){//two children

            MovieNode *min;
            MovieNode *temp= node->right;
            while(temp->left != nil){        //finds minimum of right child of node to delete
                temp = temp->left;
                }
            min = temp;

            //cout<<"the minimum left of the right this movie is "<<min->title<<endl;
            nodecolor = min->isRed;

            x = min->right;//Saving Private Ryan is under this branch

            if(min == node->right){
                node->parent->right = min;
                min->parent = node->parent;
                min->left = node->left;
                min->left->parent = min;
            }
            else{
                min->parent->left = min->right;
                min->right->parent = min->parent;
                min->parent = node->parent;
                node->parent->right=min;
                min->left = node->left;
                min->right = node->right;
                node->right->parent = min;
                node->left->parent = min;
            }
            min->isRed = node->isRed;

        }

        else{ //one child
            x = node->right;
            node->parent->right = x;
            x->parent = node->parent;
        }

    }
    if(nodecolor == false){
        rbDeleteFixup(x);
    }
    delete node;

}
void MovieTree::rightRotate(MovieNode * x){

    MovieNode* y= x->left;
    x->left = y->right;


    if(y->right != nil){
        y->right->parent = x;
    }
    y->parent = x->parent;
    if(x->parent == nil){
        root=y;
    }
    else{
        if(x == x->parent->right){
            x->parent->right = y;
        }
        else{
            x->parent->left=y;
        }
    }
    y->right = x;
    x->parent=y;

}
void MovieTree::rbDeleteFixup(MovieNode * x){
    MovieNode *s = new MovieNode;
    while (x != root && x->isRed == false){
        if(x == x->parent->left){
            s = x->parent->right;
            if(s->isRed == true){
                s->isRed=false;
                x->parent->isRed=true;
                leftRotate(x->parent);
                s = x->parent->right;
            }
            if(s->left->isRed==false && s->right->isRed == false){
                s->isRed=true;
                x=x->parent;
            }
            else if(s->left->isRed == true  && s->right->isRed == false){
                s->left->isRed = false;
                s->isRed = true;
                rightRotate(s);
                s= x->parent->right;
            }
            else{
                s->isRed = x->parent->isRed;
                x->parent->isRed = false;
                s->right->isRed = false;
                leftRotate(x->parent);
                x = root;
            }

        }
        else{ //if x is a right child instead of left
            s = x->parent->left;
            if(s->isRed == true){
                s->isRed=false;
                x->parent->isRed=true;
                rightRotate(x->parent);
                s = x->parent->right;
            }
            if(s->right->isRed==false && s->left->isRed == false){
                s->isRed=true;
                x=x->parent;
            }
            else if(s->right->isRed == true  && s->left->isRed == false){
                s->right->isRed = false;
                s->isRed = true;
                leftRotate(s);
                s= x->parent->left;
            }
            else{
                s->isRed = x->parent->isRed;
                x->parent->isRed = false;
                s->left->isRed = false;
                rightRotate(x->parent);
                x = root;
            }
    }
}
x->isRed=false;
}
void MovieTree::rbTransplant(MovieNode * u, MovieNode * v){}
int MovieTree::countMovieNodes(MovieNode *node, int *c){

    if(node == nil){
        return +1;
        }

    countMovieNodes( node->left, c);

    countMovieNodes( node->right, c);

    (*c)++;

}
int MovieTree::countLongestPath(MovieNode *node){

    if(node == nil){
        return 0;
    }


    int left = countLongestPath(node->left);
    int right = countLongestPath(node->right);


    if(left > right){
        return left + 1;
    }
    else{return right + 1;}


}

MovieNode* MovieTree::searchMovieTree(MovieNode * node, std::string title){

 if (node != nil){
        if (title < node->title){
            node = searchMovieTree(node->left, title);
            }
        else if (node->title < title){
            node = searchMovieTree(node->right, title);
            }
    }
    return node;
}



int MovieTree::rbValid(MovieNode * node)
{
    int lh = 0;
    int rh = 0;

    // If we are at a nil node just return 1
    if (node == nil)
        return 1;

    else
    {
        // First check for consecutive red links.
        if (node->isRed)
        {
            if(node->left->isRed || node->right->isRed)
            {
                cout << "This tree contains a red violation" << endl;
                return 0;
            }
        }

        // Check for valid binary search tree.
        if ((node->left != nil && node->left->title.compare(node->title) > 0) || (node->right != nil && node->right->title.compare(node->title) < 0))
        {
            cout << "This tree contains a binary tree violation" << endl;
            return 0;
        }

        // Deteremine the height of let and right children.
        lh = rbValid(node->left);
        rh = rbValid(node->right);

        // black height mismatch
        if (lh != 0 && rh != 0 && lh != rh)
        {
            cout << "This tree contains a black height violation" << endl;
            return 0;
        }

        // If neither height is zero, incrament if it if black.
        if (lh != 0 && rh != 0)
        {
                if (node->isRed)
                    return lh;
                else
                    return lh+1;
        }

        else
            return 0;

    }
}
