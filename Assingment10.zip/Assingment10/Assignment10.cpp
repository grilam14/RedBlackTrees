#include <iostream>
#include "MovieTree.h"
#include <fstream>
#include <sstream>
#include <cstdlib>

using namespace std;

int main(int argc, char* argv[]){
MovieTree m;



ifstream data (argv[1]);
//ifstream data (filename);

string word;

while(getline(data, word, '\n')){

    int counter=1;

    stringstream ss;
    ss<<word;

    int ranking;
    string title;
    int year;
    int quantity;

    while(getline(ss,word,',')){

        if(counter==1){
            ranking = atoi(word.c_str());
            counter++;
            continue;
        }
        if(counter==2){
            title = word;
            counter++;
            continue;

        }
        if(counter==3){
            year = atoi(word.c_str());
            counter++;
            continue;
        }
        if(counter ==4){

            quantity = atoi(word.c_str());
            counter=1;
            m.addMovieNode(ranking, title, year, quantity);
        }
    }
}

bool run = true;

while(run == true){

    string command;
    cout << "======Main Menu======" << endl;
    cout << "1. Find a movie" << endl;
    cout << "2. Rent a movie" << endl;
    cout << "3. Print the inventory" << endl;
    cout << "4. Delete a movie" << endl;
    cout << "5. Count the movies" << endl;
    cout << "6. Count the longest path"<<endl;
    cout << "7. Quit" << endl;

    getline(cin, command);
     if(command == "1"){
        string movie;
        cout << "Enter title:" << endl;
        getline(cin, movie);

        m.findMovie(movie);
    }
    if(command == "2"){
        string movie;
        cout << "Enter title:" << endl;
        getline(cin, movie);

        m.rentMovie(movie);

    }
    if(command == "3"){

        m.printMovieInventory();
    }
    if(command == "4"){
        string movie;
        cout << "Enter title:" << endl;
        getline(cin, movie);

        m.deleteMovieNode(movie);

    }
    if(command == "5"){
        cout<<"Tree contains: "<<m.countMovieNodes()<< " movies."<<endl;

    }

    if(command == "6"){

        cout<<"Longest Path: " << m.countLongestPath() <<endl;

    }

    if(command == "7"){
        cout << "Goodbye!" << endl;
        run = false;
    }
}


return 0;
}
